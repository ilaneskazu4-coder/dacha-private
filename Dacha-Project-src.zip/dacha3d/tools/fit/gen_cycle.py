import sys; sys.path.insert(0,'/home/claude/fit')
import numpy as np,json,fourier as F
v=np.array(json.load(open(sys.argv[1])))
S=float(np.exp(v[-1])) if len(v)==F.NP else json.load(open('/home/claude/fit/f0.json'))['s']
rows=[];tys=[]
P=[F.pose(v,i) for i in range(36)]
ty=np.array([p[2] for p in P]); bob=-(ty-ty.mean())/S*0.95
bob=np.clip(bob,-0.12,0.12)
vals=[]
for i in range(36):
    x=P[i][0]
    vals+=list(x)+[bob[i]]
txt="class_name RunCycle\n## Цикл бега Тревора: углы суставов подогнаны по кадрам референса (36 кадров). Генерируется tools/gen_cycle.py\nconst N := 36\nconst PHASE_OFF := 0.0\nconst ARM_IN := 0.2    # руки ближе к корпусу (вид сзади)\nconst LEG_IN := 0.1    # ноги ближе к центральной линии\nconst BONES := [0, 1, 2, 3, 4, 5, 6, 8, 9, 11, 12, 13, 14, 15, 16]\nconst DATA: Array = [\n"
for i in range(36):
    txt+="\t"+", ".join("%.4f"%a for a in vals[i*16:(i+1)*16])+(",\n" if i<35 else "]\n")
open('/home/claude/dacha3d/scripts/run_cycle.gd','w').write(txt)
print('bob range',bob.min(),bob.max())
