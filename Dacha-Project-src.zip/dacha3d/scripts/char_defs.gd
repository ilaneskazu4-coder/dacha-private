class_name CharDefs
## Описание играбельных героев: скелет под их пропорции, зоны влияния костей для запекания весов, пути к ресурсам.
## Порядок костей одинаков у всех (индексы в HeroRig.I_*): 0 hips, 1 spine, 2 chest, 3 neck, 4 head,
## 5-7 рука «p» (+X) плечо/предплечье/кисть, 8-10 рука «n» (−X), 11-13 нога «p», 14-16 нога «n».

const A_ID := 0
const B_ID := 1
const NAMES := ["Михалыч", "Тревор"]


static func get_def(id: int) -> Dictionary:
	return A if id == 0 else B


const A := {
	"id": 0,
	"mesh": "res://assets/hero/hero_mesh.res",
	"scale": 0.95,
	"rest_drop": 0.0,
	"lower": 1.28,
	"hand_off": Vector3(-0.02, 0.0, 0.03),
	"bones": [
		["hips", -1, Vector3(0, 0.70, 0)],
		["spine", 0, Vector3(0, 0.14, 0)],
		["chest", 1, Vector3(0, 0.14, 0)],
		["neck", 2, Vector3(0, 0.20, 0)],
		["head", 3, Vector3(0, 0.12, 0)],
		["arm_p", 2, Vector3(0.27, 0.19, 0)],
		["fore_p", 5, Vector3(0.25, 0, 0)],
		["hand_p", 6, Vector3(0.21, 0, 0)],
		["arm_n", 2, Vector3(-0.27, 0.19, 0)],
		["fore_n", 8, Vector3(-0.25, 0, 0)],
		["hand_n", 9, Vector3(-0.21, 0, 0)],
		["thigh_p", 0, Vector3(0.115, -0.02, 0)],
		["shin_p", 11, Vector3(0, -0.32, 0)],
		["foot_p", 12, Vector3(0, -0.26, 0)],
		["thigh_n", 0, Vector3(-0.115, -0.02, 0)],
		["shin_n", 14, Vector3(0, -0.32, 0)],
		["foot_n", 15, Vector3(0, -0.26, 0)]],
}

const B := {
	"id": 1,
	"mesh": "res://assets/hero2/hero2_mesh.res",
	"scale": 0.95,
	"rest_drop": 0.85,
	"lower": 1.28,
	"hand_off": Vector3(-0.03, -0.04, 0.03),
	"bones": [
		["hips", -1, Vector3(0, 0.95, 0)],
		["spine", 0, Vector3(0, 0.13, 0)],
		["chest", 1, Vector3(0, 0.17, 0)],
		["neck", 2, Vector3(0, 0.27, 0)],
		["head", 3, Vector3(0, 0.12, 0)],
		["arm_p", 2, Vector3(0.19, 0.25, 0)],
		["fore_p", 5, Vector3(0.22, -0.25, 0)],
		["hand_p", 6, Vector3(0.13, -0.22, 0)],
		["arm_n", 2, Vector3(-0.19, 0.25, 0)],
		["fore_n", 8, Vector3(-0.22, -0.25, 0)],
		["hand_n", 9, Vector3(-0.13, -0.22, 0)],
		["thigh_p", 0, Vector3(0.09, -0.04, 0)],
		["shin_p", 11, Vector3(0, -0.37, 0)],
		["foot_p", 12, Vector3(0, -0.42, 0)],
		["thigh_n", 0, Vector3(-0.09, -0.04, 0)],
		["shin_n", 14, Vector3(0, -0.37, 0)],
		["foot_n", 15, Vector3(0, -0.42, 0)]],
}

# Зоны влияния костей (отрезки в глобальных координатах T/A-позы, ноги на y=0)
const SEGS_A := {
	0: [[Vector3(-0.14, 0.72, 0), Vector3(0.14, 0.72, 0)], [Vector3(-0.14, 0.62, 0), Vector3(0.14, 0.62, 0)]],
	1: [[Vector3(-0.2, 0.84, 0), Vector3(0.2, 0.84, 0)]],
	2: [[Vector3(-0.22, 0.98, 0), Vector3(0.22, 0.98, 0)], [Vector3(-0.22, 1.1, 0), Vector3(0.22, 1.1, 0)]],
	3: [[Vector3(0, 1.2, 0), Vector3(0, 1.3, 0)]],
	4: [[Vector3(0, 1.34, 0), Vector3(0, 1.72, 0)], [Vector3(0, 1.8, 0), Vector3(0, 1.9, 0)]],
	5: [[Vector3(0.31, 1.17, 0), Vector3(0.52, 1.17, 0)]],
	6: [[Vector3(0.52, 1.17, 0), Vector3(0.73, 1.17, 0)]],
	7: [[Vector3(0.73, 1.17, 0), Vector3(0.88, 1.17, 0)]],
	8: [[Vector3(-0.31, 1.17, 0), Vector3(-0.52, 1.17, 0)]],
	9: [[Vector3(-0.52, 1.17, 0), Vector3(-0.73, 1.17, 0)]],
	10: [[Vector3(-0.73, 1.17, 0), Vector3(-0.88, 1.17, 0)]],
	11: [[Vector3(0.115, 0.68, 0), Vector3(0.115, 0.36, 0)]],
	12: [[Vector3(0.115, 0.36, 0), Vector3(0.115, 0.1, 0)]],
	13: [[Vector3(0.115, 0.1, 0), Vector3(0.115, 0.03, 0.1)]],
	14: [[Vector3(-0.115, 0.68, 0), Vector3(-0.115, 0.36, 0)]],
	15: [[Vector3(-0.115, 0.36, 0), Vector3(-0.115, 0.1, 0)]],
	16: [[Vector3(-0.115, 0.1, 0), Vector3(-0.115, 0.03, 0.1)]]}

const SEGS_B := {
	0: [[Vector3(-0.14, 0.93, 0), Vector3(0.14, 0.93, 0)], [Vector3(-0.14, 0.99, 0), Vector3(0.14, 0.99, 0)]],
	1: [[Vector3(-0.17, 1.1, 0), Vector3(0.17, 1.1, 0)]],
	2: [[Vector3(-0.2, 1.26, 0), Vector3(0.2, 1.26, 0)], [Vector3(-0.2, 1.42, 0), Vector3(0.2, 1.42, 0)]],
	3: [[Vector3(0, 1.52, 0), Vector3(0, 1.6, 0)]],
	4: [[Vector3(0, 1.66, 0), Vector3(0, 1.84, 0)]],
	5: [[Vector3(0.23, 1.48, 0), Vector3(0.41, 1.25, 0)]],
	6: [[Vector3(0.41, 1.25, 0), Vector3(0.54, 1.03, 0)]],
	7: [[Vector3(0.54, 1.03, 0), Vector3(0.6, 0.9, 0)]],
	8: [[Vector3(-0.23, 1.48, 0), Vector3(-0.41, 1.25, 0)]],
	9: [[Vector3(-0.41, 1.25, 0), Vector3(-0.54, 1.03, 0)]],
	10: [[Vector3(-0.54, 1.03, 0), Vector3(-0.6, 0.9, 0)]],
	11: [[Vector3(0.09, 0.91, 0), Vector3(0.09, 0.54, 0)]],
	12: [[Vector3(0.09, 0.54, 0), Vector3(0.09, 0.12, 0)]],
	13: [[Vector3(0.09, 0.12, 0), Vector3(0.09, 0.05, 0.13)]],
	14: [[Vector3(-0.09, 0.91, 0), Vector3(-0.09, 0.54, 0)]],
	15: [[Vector3(-0.09, 0.54, 0), Vector3(-0.09, 0.12, 0)]],
	16: [[Vector3(-0.09, 0.12, 0), Vector3(-0.09, 0.05, 0.13)]]}
