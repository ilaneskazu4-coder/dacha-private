extends Node3D
func _ready() -> void:
	var env := WorldEnvironment.new(); env.environment = Environment.new()
	env.environment.background_mode = Environment.BG_COLOR; env.environment.background_color = Color(0.8,0.78,0.7)
	env.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR; env.environment.ambient_light_color = Color(0.85,0.85,0.85)
	add_child(env)
	var l := DirectionalLight3D.new(); l.rotation_degrees = Vector3(-45,30,0); add_child(l)
	var cam := Camera3D.new(); add_child(cam)
	cam.position = Vector3(0,1.55,2.4); cam.rotation_degrees = Vector3(-12,0,0); cam.fov = 45
	var h := HeroRig.new(); h.setup({"char": 1}); add_child(h)
	await get_tree().create_timer(0.3).timeout
	var spd := 2.6     # «прогулочный» шаг стиком
	for i in 40: h.animate(0.033, spd); await get_tree().process_frame
	# один цикл ~ 1.0 с, снимаем 20 кадров по 0.05 с
	for k in 20:
		for j in 2: h.animate(0.025, spd); await get_tree().process_frame
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png("/home/claude/dacha3d/build/wk_%02d.png" % k)
	get_tree().quit()
