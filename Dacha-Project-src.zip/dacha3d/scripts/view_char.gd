extends Node3D
func _ready() -> void:
	var env := WorldEnvironment.new(); env.environment = Environment.new()
	env.environment.background_mode = Environment.BG_COLOR; env.environment.background_color = Color(0.55,0.7,0.85)
	env.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR; env.environment.ambient_light_color = Color(0.8,0.8,0.8)
	add_child(env)
	var l := DirectionalLight3D.new(); l.rotation_degrees = Vector3(-45,30,0); add_child(l)
	var cam := Camera3D.new(); add_child(cam)
	cam.position = Vector3(0,1.1,4.2); cam.fov = 40
	var ids := [0,1]
	var rigs: Array = []
	for n in ids.size():
		var h := HeroRig.new(); h.setup({"char": ids[n]}); add_child(h); h.position = Vector3(-1.0+2.0*n,0,0); rigs.append(h)
	await get_tree().create_timer(0.5).timeout
	var t := 0.0
	for pose in 4:
		for r in rigs:
			var h: HeroRig = r
			h.rotation.y = [0.0, 0.8, PI/2, 0.0][pose]
			if pose == 3: h.punch = true
		for i in 25:
			for r in rigs: (r as HeroRig).animate(0.033, 3.0 if pose==2 else 0.0)
			await get_tree().process_frame
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png("/home/claude/dacha3d/build/view_%d.png" % pose)
	get_tree().quit()
