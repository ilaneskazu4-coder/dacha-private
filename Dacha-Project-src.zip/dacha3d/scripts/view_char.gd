extends Node3D
func _ready() -> void:
	var env := WorldEnvironment.new(); env.environment = Environment.new()
	env.environment.background_mode = Environment.BG_COLOR; env.environment.background_color = Color(0.7,0.8,0.9)
	env.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR; env.environment.ambient_light_color = Color(0.85,0.85,0.85)
	add_child(env)
	var l := DirectionalLight3D.new(); l.rotation_degrees = Vector3(-45,30,0); add_child(l)
	var cam := Camera3D.new(); add_child(cam)
	cam.position = Vector3(0,1.0,3.6); cam.fov = 40
	var h := HeroRig.new(); h.setup({"char": 1}); add_child(h)
	h.rotation.y = PI * 0.9
	await get_tree().create_timer(0.4).timeout
	var poses := ["idle","walk","aim","punch0","punch1","punch2","rage","slam","seat","air","chop","run"]
	for k in poses.size():
		h.aim = false; h.punch = false; h.air = false; h.seat = 0.0; h.rage = false; h.slam = -1.0
		var spd := 0.0
		var sw := NAN
		match poses[k]:
			"walk": spd = 3.2
			"run": spd = 6.0
			"aim": h.aim = true; spd = 3.0
			"punch0", "punch1", "punch2": h.punch = true; h.attack_kind = int(poses[k].substr(5)); sw = 1.6
			"air": h.air = true; h.vy = 3.0
			"seat": h.seat = 1.0
			"rage": h.rage = true
			"slam": h.slam = 0.5
			"chop": sw = 1.6
		for i in 45:
			h.swing_angle = sw if not is_nan(sw) else NAN
			h.animate(0.033, spd)
			await get_tree().process_frame
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png("/home/claude/dacha3d/build/pz_%02d.png" % k)
	get_tree().quit()
