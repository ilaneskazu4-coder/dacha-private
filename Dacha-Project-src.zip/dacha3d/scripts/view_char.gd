extends Node3D
func _ready() -> void:
	var env := WorldEnvironment.new(); env.environment = Environment.new()
	env.environment.background_mode = Environment.BG_COLOR; env.environment.background_color = Color(0.7,0.72,0.76)
	env.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR; env.environment.ambient_light_color = Color(0.85,0.85,0.85)
	add_child(env)
	var l := DirectionalLight3D.new(); l.rotation_degrees = Vector3(-45,30,0); add_child(l)
	var cam := Camera3D.new(); add_child(cam)
	cam.fov = 45
	var h := HeroRig.new(); h.setup({"char": 1}); add_child(h)
	await get_tree().create_timer(0.3).timeout
	for mode in 4:
		var spd := 5.0 if mode < 2 else 2.4
		if mode % 2 == 0:
			h.rotation.y = 0.0; cam.position = Vector3(0,1.5,2.6); cam.rotation_degrees = Vector3(-12,0,0)
		else:
			h.rotation.y = PI * 0.5; cam.position = Vector3(0,1.2,3.0); cam.rotation_degrees = Vector3(-5,0,0)
		for i in 45: h.animate(0.033, spd); await get_tree().process_frame
		for k in 10:
			for j in 2: h.animate(0.033, spd); await get_tree().process_frame
			await RenderingServer.frame_post_draw
			get_viewport().get_texture().get_image().save_png("/home/claude/dacha3d/build/rn_%d_%02d.png" % [mode, k])
	get_tree().quit()
