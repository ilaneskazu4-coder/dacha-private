extends Node3D
func _ready() -> void:
	var env := WorldEnvironment.new(); env.environment = Environment.new()
	env.environment.background_mode = Environment.BG_COLOR; env.environment.background_color = Color(0.45,0.5,0.55)
	env.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR; env.environment.ambient_light_color = Color(0.85,0.85,0.85)
	add_child(env)
	var l := DirectionalLight3D.new(); l.rotation_degrees = Vector3(-45,30,0); add_child(l)
	var cam := Camera3D.new(); add_child(cam)
	cam.fov = 38
	cam.position = Vector3(0,0.95,3.3)
	var h := HeroRig.new(); h.setup({"char": 1}); add_child(h)
	var yaw := float(OS.get_environment("VY")) if OS.has_environment("VY") else -90.0
	h.rotation.y = deg_to_rad(yaw)
	await get_tree().create_timer(0.3).timeout
	var n := 0
	for spd in [0.0, 2.4, 5.0]:
		for i in 50: h.animate(0.033, spd); await get_tree().process_frame
		var dt := 1.0 / 15.0
		for k in 12:
			var steps := 2
			for j in steps: h.animate(dt / steps * 2.0, spd); await get_tree().process_frame
			await RenderingServer.frame_post_draw
			get_viewport().get_texture().get_image().save_png("/home/claude/dacha3d/build/sd_%d_%02d.png" % [n, k])
		n += 1
	get_tree().quit()
