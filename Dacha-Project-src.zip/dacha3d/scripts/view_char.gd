extends Node3D
func _ready() -> void:
	var env := WorldEnvironment.new(); env.environment = Environment.new()
	env.environment.background_mode = Environment.BG_COLOR; env.environment.background_color = Color(0.7,0.8,0.9)
	env.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR; env.environment.ambient_light_color = Color(0.85,0.85,0.85)
	add_child(env)
	var l := DirectionalLight3D.new(); l.rotation_degrees = Vector3(-45,30,0); add_child(l)
	var cam := Camera3D.new(); add_child(cam)
	cam.position = Vector3(0,1.0,3.4); cam.fov = 40
	var h := HeroRig.new(); h.setup({"char": 1}); add_child(h)
	await get_tree().create_timer(0.4).timeout
	var n := 0
	# 0-2: покой спереди, через интервалы; 3-8: ходьба сзади; 9-10: бег сбоку
	for step in 11:
		var spd := 0.0
		h.rotation.y = PI
		if step == 2: h.rotation.y = PI * 0.5
		if step >= 3 and step <= 8:
			spd = 3.2
			h.rotation.y = 0.0
		if step >= 9:
			spd = 6.0
			h.rotation.y = PI * 0.5
		var frames := 40 if step < 3 else 4
		if step == 0: frames = 20
		for i in frames:
			h.animate(0.033, spd)
			await get_tree().process_frame
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png("/home/claude/dacha3d/build/tv_%02d.png" % step)
	get_tree().quit()
